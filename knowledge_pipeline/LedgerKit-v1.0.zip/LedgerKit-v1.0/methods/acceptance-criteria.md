# Acceptance criteria for a model learning loop

## Purpose

Turn a broad goal into observable characteristics, defensible acceptance criteria, and a learning loop that knows whether to continue, release, or change approach.

The method is: **define the outcome → discover characteristics → define evidence and boundaries → select valuable tests → set acceptance rules → learn from failures → decide.**

This is a practical synthesis, not a named industry standard. It applies to classification, extraction, ranking, generated text, and other tasks when the desired behavior can be observed. The method transfers; the domain definitions, evidence, tolerances, and risks must be supplied for each application. It cannot certify “anything” without those inputs.

## 1. Define the outcome before defining labels

Write a short task contract:

> Given [available input], produce [output] so [consumer] can [decision or action], within [operating constraints]. A false claim causes [consequence]; a missed claim causes [consequence]. When evidence is insufficient, [fallback].

Record scope, excluded uses, supported languages or sources, latency and cost limits, and who owns acceptance. Identify whether the system measures what the text says, what actually happened, or what someone should do. These require different evidence.

For example, “identify articles reporting a consumer price increase” is different from “verify that prices actually increased.” Article text can support the former without establishing the latter.

**Output:** one task contract. Unknown requirements stay explicit; the agent does not invent them.

## 2. Discover the characteristics that make the outcome true

Start with a broad but bounded sample of real inputs. Include ordinary cases, different sources, likely failures, and examples that do not qualify. Use documents, domain expertise, existing errors, and downstream decisions to propose characteristics.

For every concept, ask:

| Question | What to extract |
|---|---|
| What must be present? | Necessary evidence or conditions |
| What establishes a positive case? | Sufficient evidence, when definable |
| What rules it out? | Exclusions and contradictory evidence |
| What is easily confused with it? | Nearest competing concepts and hard negatives |
| Who or what does the evidence describe? | Actor, object, relationship, attribution |
| When and under what conditions does it apply? | Time, scope, modality, conditions |
| What information is missing? | Unknown, ambiguity, or abstention conditions |
| What change should alter the answer? | A meaningful contrast or boundary |
| What change should preserve the answer? | A valid invariance |

Distinguish three things: a **target characteristic** defines the requested output; an **evidence cue** may support it; a **slice attribute** identifies circumstances in which to evaluate it. A keyword is usually a cue, not a definition. A language or source is usually a slice, not a label.

Break a concept apart only when the distinction changes the expected answer, the error diagnosis, the downstream action, or a material risk. Avoid collecting attributes simply because they are extractable.

### Example: a reported consumer price increase

An illustrative definition might require an explicit report that the price charged to consumers for a good or service has increased, under an agreed time policy.

| Characteristic | Positive evidence | Boundary or exclusion |
|---|---|---|
| Object | A consumer good or service | A stock price alone does not qualify |
| Direction | A higher price relative to a reference | A high but unchanged price does not qualify |
| Event status | A reported increase | A hypothetical increase does not qualify |
| Attribution | The report identifies whose price changed | A vague reference may be insufficient |
| Time | Falls within the task’s explicit time policy | Historical background may be excluded |

Negation, forecasts, comparisons, quotations, missing context, and multiple conflicting claims are candidate test conditions. Their correct answers depend on the codebook, not on a universal rule.

**Output:** a characteristic register, with each entry marked required, diagnostic, exploratory, or out of scope.

## 3. Make each characteristic observable and labelable

For every target, write a compact codebook entry:

1. Definition and unit of judgment: document, sentence, span, entity, or relationship.
2. Inclusion rules, exclusion rules, and treatment of multiple claims.
3. Clear positive, clear negative, closest confusing case, and insufficient-evidence example.
4. Evidence required from the input: a span, field, verified event, or explicit relationship.
5. The allowed outputs, including ambiguity or abstention where appropriate.

If the task requires several conditions together, say which are necessary and which combinations are sufficient. For a subjective task, specify whose judgment or range of acceptable answers the system represents.

Have independent qualified reviewers apply the codebook to an overlapping pilot sample, blind to model predictions. Preserve initial judgments before adjudication. Report disagreements, class support, and agreement measures appropriate to the task. Inspect rare positives separately: abundant easy negatives can conceal poor understanding of the target.

Use disagreement to diagnose unclear definitions, missing information, reviewer mistakes, or legitimate perspectives. Do not automatically turn every disagreement into a single majority label. Different model vendors do not guarantee independent errors. Model-only references can support a provisional learning loop, but agreement with them does not independently establish correctness.

Do not impose one universal alpha threshold. Choose and justify reliability requirements for the use case. Judge agreement is a diagnostic of the reference process, **not a mathematical ceiling on model performance**.

**Output:** versioned codebook and reference-label audit. Unresolved cases are recorded rather than silently discarded.

## 4. Build a wide test map, then prioritize it

Map each target to the relevant test families:

| Family | Question |
|---|---|
| Basic capability | Can it recognize clear qualifying cases? |
| Discrimination | Does it reject the closest nonqualifying cases? |
| Boundaries | Does it handle negation, timing, scope, thresholds, and missing evidence? |
| Robustness | Do validated meaning-preserving edits preserve the answer? |
| Meaningful change | Does a task-relevant edit produce the specified change? |
| Important slices | Does it work on relevant sources, languages, lengths, and populations? |
| Relationships | Are combinations, exclusions, and dependencies handled correctly? |
| Downstream effect | Does the resulting action meet the consumer’s needs? |
| Operation | Does it meet latency, cost, coverage, and fallback constraints? |

These families are prompts, not mandatory tests for every label. CheckList provides an established basis for capability-oriented behavioral tests [1]. The additional workflow here is our synthesis.

Prioritize using failure evidence, expected exposure, consequence, and uncertainty. A qualitative risk register is sufficient initially. Investigate rare severe failures even when their average contribution is small. Test interactions suggested by the task or observed failures; pairwise coverage does not prove classifier completeness.

Keep broad discovery coverage while concentrating effort where it can change a decision. Record why a candidate was selected, deferred, or excluded. Stop expanding the initial map when a bounded discovery pass produces no new decision-relevant characteristic or failure category; reopen it when new evidence appears. This is a practical discovery stop, not proof of completeness.

**Output:** a prioritized test map linked to the task contract.

## 5. Keep learning evidence separate from acceptance evidence

| Evidence set | Purpose | Permitted use |
|---|---|---|
| Training | Fit model parameters | Learning |
| Development | Discover errors, choose features, models, and thresholds | Repeated iteration |
| Acceptance | Evaluate the selected candidate against committed rules | Limited, planned release decisions |
| Production audit | Detect drift and newly exposed failures | Monitoring and future cycles |

Separate related documents, duplicates, source events, and transformed variants into the same split where needed. Use time or source holdouts when those match the deployment question. Split before fitting preprocessing or using label-dependent selection.

Maintain both a deployment-representative sample and targeted challenge sets. Targeted positives and hard negatives help diagnose behavior; their raw aggregate rates do not estimate deployment rates. Report the sets separately, or use a documented sampling design and valid weighting.

Model-assisted mining is useful for development and challenges. It must not be the sole way of selecting the supposedly representative acceptance sample.

Repeatedly inspecting acceptance failures and adapting to them makes that set part of development. Preserve exposed failures as regressions, then obtain fresh independent evidence for the next acceptance decision. An unchanged file is not necessarily an independent test [2].

**Output:** versioned set manifests, split policy, and exposure history.

## 6. Turn selected behaviors into acceptance criteria

Use this record for each criterion:

> For [target and scope], on [specified evidence set and selection method], at [fixed operating point], [metric with denominator] must meet [threshold and uncertainty rule]. This protects [consumer outcome or risk]. Its basis is [requirement, measurement, or explicitly provisional assumption]. Evidence is insufficient if [support condition]. Owner: [role].

Record the scorer, reference policy, dataset and model versions, sample support, and an illustrative failure. A hypothetical counterexample is acceptable before failures exist. A single example demonstrates a failure mode; the metric decides whether the aggregate rule fails.

### Derive the threshold

Start with what the consumer can tolerate, contractual requirements, resource constraints, or measured downstream utility. Use replay, observation, controlled experiments, and sensitivity analysis where appropriate. Error injection is one option; its error patterns must resemble plausible failures.

Measure simple and existing-system baselines on comparable evidence. A baseline reveals whether the candidate adds value; it does not determine acceptable risk. A useful replacement may offer equal quality with lower cost or latency. If the required quality is unattainable, change the system, fallback, or scope through an explicit decision rather than lowering the bar after seeing results.

Label unsupported thresholds **provisional**, with an owner and a measurement task. A provisional target guides development; it is not evidence of readiness.

### Use the correct denominator

| Metric | Denominator |
|---|---|
| Recall | Actual positives |
| Precision | Predicted positives |
| False-positive rate | Actual negatives |
| False alerts per 1,000 inputs | All incoming inputs |
| Coverage | All eligible inputs; numerator is those decided automatically |
| Conditional quality with abstention | Automatically decided cases, reported alongside coverage |

For prevalence π, false alerts per 1,000 inputs = 1,000 × (1 − π) × false-positive rate. These rates are not interchangeable.

Choose sample size for the claim, including rare positives and important slices. For an ordinary fixed-sample binomial rate, specify an appropriate interval and whether the bound is one-sided or two-sided [3]. Zero observed errors does not demonstrate zero risk. For example, zero errors in 299 independent trials gives a one-sided exact 95% upper error bound just below 1%, using 1 − 0.05^(1/n). Clustered documents and generated variants do not supply 299 independent trials merely by having 299 rows.

Use paired comparisons for candidate versus incumbent on shared items. Choose a suitable method for the statistic; Wilson intervals are not a universal method for F1, latency, or correlated samples. Predeclare primary criteria and evaluation checkpoints. Many exploratory slices and repeated looks require care about multiple comparisons and selection effects.

**Output:** criteria with justified bars, denominators, evidence requirements, and decision rules.

## 7. Run a learning loop that identifies the next useful change

For each development round:

1. Evaluate the current candidate and incumbent on the same development evidence.
2. Classify failures: definition, reference label, missing input, coverage, learned behavior, operating threshold, or downstream integration.
3. Rank failure groups by consequence, expected exposure, plausible improvement, and cost to investigate. Use qualitative estimates until measurements support numerical ones.
4. Choose a bounded intervention and state its predicted effect before running it. Examples include revising an unclear definition, labeling underrepresented cases, adding hard negatives, changing representation, adjusting a threshold, or adding a fallback.
5. Retrain or adjust, then measure the predicted improvement and protected regressions. Record unsuccessful interventions too.
6. Retain the candidate only if the relevant evidence supports it; otherwise revert or investigate.

Select new labeling examples from a mixture of representative inputs, high-impact errors, disagreements, uncertain cases, and undercovered slices. Uncertainty alone can miss confidently wrong regions. Keep development failures and new challenge cases versioned; never quietly fold acceptance examples into training while continuing to call them held out.

When references come only from noisy teachers, distinguish **better agreement with the teachers** from **better performance on the intended task**. Obtain independent audits before claiming the latter.

**Output:** a round log: hypothesis, change, data added, measured effect, regressions, cost, and next action.

## 8. Separate release readiness from the limit of further learning

| Decision | Evidence required | Action |
|---|---|---|
| Accept | Valid evaluation; all mandatory criteria pass; operational constraints pass | Release within tested scope; monitor |
| Continue | A material gap remains and a plausible intervention is available | Run the next bounded experiment |
| Inconclusive | Insufficient support, wide uncertainty, or unreliable reference | Gather evidence; do not claim a pass |
| Plateau | Predeclared rounds show too little useful gain | Change data, definition, representation, or approach |
| Pause or stop | Budget exhausted or expected next-step value is too low | Record unmet criteria and choose fallback or scope change |

Before iteration, specify a minimum worthwhile gain, protected regression limits, a round or labeling budget, and how long to tolerate a plateau. These are project decisions, not universal constants. For example, “reconsider this approach after three well-measured rounds without a worthwhile gain” is a planning rule, not proof of an intrinsic ceiling.

Assess gains on development data and learning curves. A plateau may reflect noisy labels, missing evidence, inadequate representation, data scarcity, optimization, or insufficient measurement precision. It does not establish the best possible model performance.

Acceptance criteria define **good enough for a stated use**. Stop rules define **whether another learning round is worth doing**. The theoretical limit is generally unknown. Passing the criteria need not mean maximum performance; exhausting the budget does not mean passing.

Mandatory criteria are combined with AND. Optional metrics and utility scores may guide optimization, but cannot compensate for a failed mandatory requirement. A valid false-alarm criterion can be passed by an always-negative model; pair it with recall or useful-coverage requirements. Valid abstention must not become a way to evade evaluation.

Version criteria before acceptance runs. Revise them when requirements, evidence, reference policy, or context changes, with the reason recorded. Never revise them merely to turn a failing candidate into a passing one. NIST’s lifecycle framework supports documented, contextual evaluation and continuing monitoring [4].

## Compact example: cancellation-intent routing

Illustrative policy and targets only; these are not industry defaults.

**Goal:** identify explicit subscription-cancellation requests and route them to a support queue. Order cancellations, negated requests, and vague dissatisfaction are handled according to an explicit codebook. Ambiguous cases go to manual triage.

**Characteristics:** object being cancelled, expressed intent, negation, attribution, timing, and evidence sufficiency. Source and language are evaluation slices. The word “cancel” is a cue, not sufficient evidence.

**Consumer requirement:** at 4,000 inputs per day, at most 40 unnecessary cancellation routes are tolerable. This yields a point target of 10 false routes per 1,000 total inputs. Use an appropriate representative audit and upper confidence bound for the acceptance claim; do not substitute a curated hard-negative set for the live denominator.

Separate mandatory criteria might require:

- The upper one-sided 95% bound on false routes per input is at most 1% on the representative acceptance audit.
- The lower one-sided 95% recall bound is at least the separately justified recall target, using enough reference-positive cases.
- Automatic coverage meets a separately justified minimum, and manual volume stays within capacity.
- The candidate satisfies the agreed noninferiority limits for protected behaviors and operational limits.

If false routes concentrate on “cancel my last order,” add adjudicated development examples and test that distinction. If reference reviewers cannot distinguish a request from a hypothetical question, repair the codebook before collecting more labels under it. Once development criteria are met, freeze the candidate and run the acceptance evaluation under the planned decision policy.

## Reusable agent instruction

Given a task description and representative examples, produce: (1) a task contract; (2) a characteristic register separating target, cue, and slice; (3) a codebook with evidence, boundaries, exclusions, and ambiguity handling; (4) a prioritized test map; (5) a data-split and reference-validation plan; (6) atomic acceptance criteria with denominators, threshold derivations, and uncertainty rules; (7) a bounded learning plan; and (8) explicit release, inconclusive, plateau, and budget-stop rules.

Do not invent consumer tolerances, claim model agreement is truth, treat reviewer agreement as a ceiling, infer deployment rates from curated challenges, reuse exposed tests as independent evidence, or weaken criteria after observing failures. Mark unresolved inputs and unsupported thresholds explicitly. Keep every criterion traceable to the characteristic and consumer outcome it protects.

## Sources and attribution

The workflow, templates, prioritization, and example above are a practical synthesis. The sources support the specific principles indicated, not every proposed process choice or numerical target.

1. Ribeiro et al., 2020. [Beyond Accuracy: Behavioral Testing of NLP Models with CheckList](https://aclanthology.org/2020.acl-main.442/). Capability-oriented testing; minimal functionality, invariance, and directional expectations. [Authors’ implementation](https://github.com/marcotcr/checklist).
2. scikit-learn. [Cross-validation: evaluating estimator performance](https://scikit-learn.org/stable/modules/cross_validation.html). Separation of model selection from test evaluation; group and time-aware evaluation strategies.
3. NIST/SEMATECH. [Confidence intervals for proportions](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm). Binomial proportion uncertainty. The 299-trial example is calculated directly from the stated exact one-sided zero-error formula.
4. NIST. [AI RMF Core](https://airc.nist.gov/airmf-resources/airmf/5-sec-core/). Contextual risk management, evaluation, documentation, and lifecycle monitoring.
5. Fleisig, Abebe, and Klein, 2023. [When the Majority is Wrong: Modeling Annotator Disagreement for Subjective Tasks](https://arxiv.org/abs/2305.06626). Why disagreements in subjective annotation may contain meaningful perspectives rather than simple labeling noise.
