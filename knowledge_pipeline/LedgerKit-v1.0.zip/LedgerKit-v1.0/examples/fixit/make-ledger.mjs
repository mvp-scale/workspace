// How the example ledger was written: every line goes through the kit's tool, so every line is checked against the contract, chained,
// and warned on exactly as real work would be. It shows each state the viewer has: passed, in progress part way, blocked, awaiting a
// verdict, failed with a retry, a P1 bug moved first by a focus line, work waiting on other work, stalled work, and a rule ready to enforce.
//   node examples/fixit/make-ledger.mjs     (refuses when the ledger already exists)
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { append } from '../../cp.mjs';

const P = dirname(fileURLToPath(import.meta.url));
if (existsSync(join(P, 'ledger.jsonl'))) { console.log('examples/fixit/ledger.jsonl exists; remove it to write it again'); process.exit(1); }
const ago = (h) => new Date(Date.now() - h * 36e5).toISOString();
const ev = (type, ref) => [{ type, ref }];
const at = (stage, domain, capability, goal) => ({ stage, domain, capability, ...(goal ? { goal } : {}) });
const task = (id, title, where, extra = {}) => ({ kind: 'task', who: 'planner', task: id, title, text: title, acceptance: ['works for a rider on a phone'], ...where, ...extra });
const r = append(P, [
  { kind: 'wave', who: 'planner', wave: 'W1', title: 'Book in a minute', goal: 'A rider books a slot in three taps', ...at('book', 'D02'), ts: ago(90) },
  task('T1', 'Show the next three open slots', at('book', 'D02', 'scheduling', 'scheduling.one-minute'), { wave: 'W1', why: 'the first slot a rider sees is the one they take', steps: ['next three slots listed', 'tapped slot held ten minutes'], validator: 'npm test', ts: ago(89) }),
  { kind: 'start', who: 'ana', task: 'T1', text: 'Ana picked it up', ts: ago(88) },
  { kind: 'step', who: 'ana', task: 'T1', step: 1, text: 'next three slots listed', ts: ago(80) },
  { kind: 'step', who: 'ana', task: 'T1', step: 2, text: 'tapped slot held ten minutes', ts: ago(72) },
  { kind: 'done', who: 'ana', task: 'T1', text: 'slots listed and held', evidence: [...ev('commit', 'c0ffee0000000000000000000000000000000001'), ...ev('validate', 'npm test green at c0ffee0')], ts: ago(70) },
  { kind: 'verdict', who: 'reviewer', task: 'T1', result: 'pass', criteria: [{ criterion: 'works for a rider on a phone', result: 'pass' }], evidence: ev('test', 'booking.test.mjs'), text: 'passes on a phone', ts: ago(66) },
  task('T2', 'Book a slot in three taps', at('book', 'D02', 'scheduling', 'scheduling.one-minute'), { wave: 'W1', needs: ['T1'], steps: ['shop page to slot in one tap', 'confirm in two more'], ts: ago(65) }),
  { kind: 'start', who: 'ben', task: 'T2', text: 'Ben picked it up', ts: ago(8) },
  { kind: 'step', who: 'ben', task: 'T2', step: 1, text: 'shop page to slot in one tap', ts: ago(3) },
  task('T3', 'Take a deposit when the slot is confirmed', at('book', 'D02', 'payment', 'payment.deposit'), { steps: ['provider chosen', 'deposit taken on confirm'], ts: ago(60) }),
  { kind: 'start', who: 'cara', task: 'T3', text: 'Cara picked it up', ts: ago(40) },
  { kind: 'block', who: 'cara', task: 'T3', text: 'waiting on the owner: which payment provider', ts: ago(38) },
  task('T4', 'List free shops nearest first', at('discover', 'D01', 'listing', 'listing.near-and-free'), { steps: ['rank by distance and next slot', 'say when a shop is full'], ts: ago(58) }),
  { kind: 'start', who: 'dev', task: 'T4', text: 'Dev picked it up', ts: ago(30) },
  { kind: 'step', who: 'dev', task: 'T4', step: 1, text: 'rank by distance and next slot', ts: ago(25) },
  { kind: 'step', who: 'dev', task: 'T4', step: 2, text: 'say when a shop is full', ts: ago(20) },
  { kind: 'done', who: 'dev', task: 'T4', text: 'free shops come first', evidence: ev('test', 'listing.test.mjs'), ts: ago(19) },
  task('T5', 'Ask the rider before extra work', at('visit', 'D03', 'repair', 'repair.ask-first'), { steps: ['finding priced', 'rider says yes in one tap'], ts: ago(56) }),
  { kind: 'start', who: 'eli', task: 'T5', text: 'Eli picked it up', ts: ago(50) },
  { kind: 'step', who: 'eli', task: 'T5', step: 1, text: 'finding priced', ts: ago(48) },
  { kind: 'step', who: 'eli', task: 'T5', step: 2, text: 'rider says yes in one tap', ts: ago(46) },
  { kind: 'done', who: 'eli', task: 'T5', text: 'approval sent', evidence: ev('commit', 'c0ffee0000000000000000000000000000000005'), ts: ago(45) },
  { kind: 'verdict', who: 'reviewer', task: 'T5', result: 'fail', criteria: [{ criterion: 'works for a rider on a phone', result: 'fail' }], evidence: ev('test', 'repair.test.mjs'), text: 'the approval link does not open on a phone', ts: ago(44) },
  { kind: 'postmortem', who: 'eli', task: 'T5', cause: 'task-definition', resolution: 'retry', evidence: ev('test', 'repair.test.mjs'), text: 'the acceptance named the message, not the phone it opens on', ts: ago(43) },
  task('B1', 'Two riders booked into one slot', at('book', 'D02', 'scheduling', 'scheduling.no-double'), { severity: 'high', blast: 'container', evidence: ev('test', 'booking.test.mjs:58'), steps: ['reproduce', 'one booking and one alternative'], ts: ago(30) }),
  task('T6', 'Tell the rider the bike is ready', at('visit', 'D03', 'handover', 'handover.ready-message'), { ts: ago(29) }),
  { kind: 'start', who: 'fay', task: 'T6', text: 'Fay picked it up', ts: ago(28) },
  task('T7', 'Settle the bill at handover', at('visit', 'D03', 'handover'), { ts: ago(27) }),
  { kind: 'start', who: 'gus', task: 'T7', text: 'Gus picked it up', ts: ago(26) },
  task('T8', 'Remind riders of the next service', at('return', 'D04', 'reminders', 'reminders.before-breakdown'), { ts: ago(100) }),
  { kind: 'start', who: 'hal', task: 'T8', text: 'Hal picked it up', ts: ago(96) },
  task('T9', 'Show the price range before booking', at('book', 'D02', 'scheduling'), { title: 'Show the price range for the repair the rider chose before they confirm the booking', steps: ['price range shown'], ts: ago(18) }),
  { kind: 'focus', who: 'ceremony', order: ['scheduling'], text: 'double bookings lose shops: scheduling goes first', evidence: ev('test', 'booking.test.mjs:58'), ts: ago(17) },
]);
console.log(r.ok ? `wrote ${r.ids.length} lines; warned: ${r.warnings.map((w) => w.rule).join(', ')}` : r);
