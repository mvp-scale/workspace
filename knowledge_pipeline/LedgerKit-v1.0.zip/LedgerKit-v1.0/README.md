# Ledger kit v1.0

A way to run any project so that every agent and person works from the same truth. Four parts, each with one job:

| Part | Its job | File |
|---|---|---|
| Contract | what is true: versioned YAML, never edited, a change is a new version | `contract/v<n>/` |
| Ledger | what is happening: one append-only line file, never edited | `ledger.jsonl` |
| Tool | the only writer of the ledger and the only way to release the contract | `cp.mjs` (with `engine.mjs`) |
| Viewer | what you read: one live page, refreshed every 30 seconds | `viewer.html`, served by `node cp.mjs serve` |

When two files disagree there is no guessing: the contract is the source of truth, the ledger is its state, the viewer only shows them, and no Markdown file holds a rule. This README explains the kit; the rules themselves live in `contract/v1.0/rules/ledger.yaml`, and `node cp.mjs readme` renders them.

## Start in five minutes

```bash
npm install                                   # one dependency, yaml, listed in package.json
node cp.mjs serve --project examples/fixit    # see a finished example first: http://127.0.0.1:18766/
# then make it yours: fill in contract/v1.0/ (or delete the optional files), and lock it
node cp.mjs release v1.0 --by <you>
node cp.mjs add T1 --title "First task" --acceptance "it works" --step "build it" --step "prove it"
node cp.mjs start T1 --who agent-a
node cp.mjs step T1 1 --who agent-a
node cp.mjs ready                             # what comes next, in order
node cp.mjs serve                             # your own project in the viewer
```

Run any verb against another project folder with `--project <dir>`.

## The example

`examples/fixit/` is a small made-up project, a bike repair booking service, with every part filled in so you can see what a complete one looks like and draw back to what you need: a north star, four journey stages, four domains with their definitions, six capabilities with entities, goals and functions, two personas with their drives, frictions and delights, outcomes with measures, stories, and a 38-line ledger. Its ledger shows every state the viewer has: passed, part way, blocked, awaiting review, failed and retrying, a P1 bug moved first by a focus line, work waiting on other work, stalled work, and a rule ready to enforce. `examples/fixit/make-ledger.mjs` shows how it was written, every line through the tool.

## The contract

`contract/v1.0/` is a template of placeholders, not yet released. Fill it in (or delete the optional files), then lock it with `node cp.mjs release v1.0 --by <who>`; from then on `verify` refuses any edit, addition or removal by name. To change anything, copy the folder to `v1.1/`, change it, and release that. Readers always use the newest released version. A version is cheap: accuracy matters, not the count.

| File | Holds | Required |
|---|---|---|
| `rules/ledger.yaml` | the ledger's rules: structure, enforcement, bugs, focus, the five rules | yes |
| `rules/process.yaml` | the steps your work passes and what proves each | no |
| `journey.yaml` | stage → domain → capability, each goal serving the level above | no |
| `capabilities/<id>.yaml` | one capability: definition, tier, entities, goals and their functions | with the journey |
| `experience.yaml` | cohorts, personas, moments, outcomes, stories: requirements, awareness and delight | no |
| `north-star.yaml` | who you serve and what you give them back, in the owner's words | no |
| `proof.yaml` | the end-to-end items that prove the whole works | no |

**The journey is optional, and worth it when you want value to line up.** Without it the ledger still runs; tasks just name no shared space. With it, every wave and task names its stage, domain, capability and goal, the tool refuses an id the contract does not hold, and the viewer reads in journey order. The definitions, settled the hard way:

- **Stage:** a step in the customer's full journey with you, from first contact until they leave, named from a standard journey model. It tells you where the customer is before any function or route.
- **Domain:** a bucket of work inside one stage, named as a noun, never a goal. It holds the records its work produces, from the one that opens it to the one that closes it.
- **Capability:** what the product can do inside one domain; it owns its entities, and its goals serve the domain's goal.
- **Function:** the underlying way a capability achieves one of its goals. Never a list of create, read, update and delete; those come along for the ride.

## The ledger

One line per fact, appended, never edited. Each line carries `prev`, the hash of the line before it, so an edited or removed line breaks the replay and `check` names it. The structure: a **Project** holds **Waves** (a batch of tasks in one shared space, one agent's context), a wave holds **Tasks**, a task holds up to four **Steps**. Bugs, ceremonies, opportunities and decisions are lines too.

**Enforcement grows with the process.** Every rule is in warn or enforce mode:

- A rule in warn mode lets the line through and the tool appends a `warning` line: the rule, what was wrong, the fix.
- After a rule warns on three separate tasks, the viewer shows it ready to enforce; a `decision` line citing those warnings turns it on.
- Some rules are enforced from day one, because letting them through costs more to undo than stopping: a corrupted ledger (bad ids, edited lines, unknown needs), done without evidence, an agent judging its own work, an id the contract does not hold, and code marked done without its validator's receipt.

**What comes next is computed, never typed.** Ready work is ordered by the latest `focus` line, then journey order, then the order it was filed. A ceremony may append a focus line that moves a domain or capability up, with the reason. A bug's priority comes from its severity and blast radius (P1 only when severity is high and blast is container or wider); low and medium bugs go to the pool, not the work.

## How an agent uses it

1. `node cp.mjs ready` — the next task, in order.
2. `node cp.mjs brief <id>` — everything to start it: its shared space, skills, validator, steps, acceptance and needs.
3. `start`, then `step <id> <k>` as each step closes, `note` for anything learned, `done <id> --evidence type:ref` with the validator's receipt.
4. A different agent appends `verdict <id> --result pass|fail --evidence mm3:<run>`. A fail gets a post-mortem; what to do about it is decided at a ceremony, from the pattern.
5. Read the tool's reply: a warning names its fix; a refusal writes nothing and names the rule.

## Best practices we learned building it

- **One word for one idea.** We once called the same 21 things element, area and capability, and every plan read as sprawl. Settle the words first, then edit files.
- **Never two sources.** Each fact lives in one place; everything else reads it. A goal written twice (once as a goal, once reworded as a function) drifts.
- **Move by archiving, then prove it.** Keep the originals in an archive, check field by field that the new home holds the same, and only then clean up.
- **Warn first, enforce after three runs.** A new process blocked on every rule turns into a queue of questions; a warning with its evidence lets the work move and teaches you which rules matter.
- **Stage first, then domain, always.** A list of domains without their stage loses the system.
- **A page tells a story, it is not a dump.** Lead with one computed line of where things stand, then a scannable board, then detail one click away. Never paste a document onto a page; link it.
- **Steps are the token-efficient pattern.** One agent reads a shared space once and works a short run of steps in it. Keep a task inside one capability and a wave inside one domain.
- **Lasting value in the contract, current focus in the ledger.** Tier and outcome measures change by a new version; what goes first changes at a ceremony.

## Making it yours

See `AGENTS.md`: the rules an agent works by, how to work and shape a task, and how to extend the kit (add a field, add a rule in warn mode, add a stage, release a version).

## Proof

`npm test` runs 23 tests: the original guide's 45 scenarios with its rules enforced, every rule added since, the contract lock, the append-only writer, the README rendering, the viewer's pulse, and every section and detail of the viewer rendered from the example, and the kit run from a fresh copy with no path outside its folder.
