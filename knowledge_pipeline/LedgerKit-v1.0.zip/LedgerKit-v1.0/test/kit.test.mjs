// The kit's tool, contract and viewer: a released version is locked, the ledger is written only by appending, the example replays,
// the README is rendered from the rules, and the kit runs from a fresh copy with no path outside itself.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync, rmSync, cpSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { KIT, versions, verify, release, contract, append, state, readme, view } from '../cp.mjs';

// A new project from the template, released as its owner would after filling it in.
function project() {
  const p = mkdtempSync(join(tmpdir(), 'kit-'));
  cpSync(join(KIT, 'contract'), join(p, 'contract'), { recursive: true });
  release(p, 'v1.0', { by: 'owner' });
  return p;
}

test('the template waits to be filled in and released; the worked example is released, intact and replays', () => {
  assert.equal(versions(KIT)[0].release, null, 'the template is released by its owner, not shipped locked');
  assert.deepEqual(verify(join(KIT, 'examples/fixit')), []);
  assert.equal(contract(join(KIT, 'examples/fixit')).version, 'v1.0');
  const st = state(join(KIT, 'examples/fixit'));
  assert.equal(Object.keys(st.tasks).length, 10);
});

test('an edited released file is refused by name, and a change goes in a new version', () => {
  const p = project();
  const f = join(p, 'contract/v1.0/north-star.yaml');
  writeFileSync(f, readFileSync(f, 'utf8') + 'more: x\n');
  assert.deepEqual(verify(p), ['v1.0/north-star.yaml changed after release']);
  assert.match(release(p, 'v1.0', { by: 'me' }).why, /never an edit/);
  cpSync(join(p, 'contract/v1.0'), join(p, 'contract/v1.1'), { recursive: true });
  rmSync(join(p, 'contract/v1.1/release.yaml'));
  writeFileSync(join(p, 'contract/v1.1/north-star.yaml'), readFileSync(join(KIT, 'contract/v1.0/north-star.yaml'), 'utf8'));
  assert.equal(release(p, 'v1.1', { by: 'me' }).ok, true);
  assert.equal(contract(p).version, 'v1.1');
  rmSync(p, { recursive: true });
});

test('the ledger is written only by appending: checked against the contract, warned on, all or nothing', () => {
  const p = project();
  assert.match(append(p, [{ kind: 'task', who: 'op', task: 'T1', title: 'x', text: 'x', acceptance: ['ok'], capability: 'nowhere' }]).why, /^unknown-space/);
  const r = append(p, [{ kind: 'task', who: 'op', task: 'T1', title: 'Demo the run', text: 'Demo the run', acceptance: ['it runs'], capability: 'first-capability', domain: 'D01', stage: 'first-stage', goal: 'first-capability.first-goal' },
    { kind: 'start', who: 'a', task: 'T1', text: 'started' }]);
  assert.deepEqual(r.warnings.map((w) => w.rule), ['no-steps']);
  const lines = readFileSync(join(p, 'ledger.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l));
  assert.deepEqual(lines.map((l) => l.kind), ['task', 'start', 'warning']);
  const v = view(p);
  const t1 = v.tasks.find((t) => t.id === 'T1');
  assert.equal(t1.label, 'In progress');
  assert.equal(t1.detail, 'no steps set');
  assert.deepEqual(t1.warnings, ['no-steps']);
  assert.deepEqual(v.journey[0].domains[0].capabilities[0].tasks, ['T1']);
  assert.equal(v.counts.live, 1);
  rmSync(p, { recursive: true });
});

test('a project with no journey still runs its ledger, with no shared space', () => {
  const p = project();
  rmSync(join(p, 'contract/v1.0/journey.yaml'));
  rmSync(join(p, 'contract/v1.0/release.yaml'));
  release(p, 'v1.0', { by: 'me' });
  assert.equal(append(p, [{ kind: 'task', who: 'op', task: 'T1', title: 'Anything', text: 'Anything', acceptance: ['done'] }]).ok, true);
  assert.deepEqual(view(p).journey, []);
  assert.equal(view(p).tasks[0].label, 'Ready');
  rmSync(p, { recursive: true });
});

test('the README is rendered from the contract rules, every section in it', () => {
  const c = contract(join(KIT, 'examples/fixit'));
  const text = readme(c);
  for (const k of Object.keys(c.rules.ledger).filter((k) => k !== 'purpose')) assert.ok(text.includes(`## ${k.replace(/_/g, ' ').replace(/^./, (x) => x.toUpperCase())}`), k);
});

test('the viewer asks for fresh data every 30 seconds and redraws only when it changed', () => {
  const page = readFileSync(join(KIT, 'viewer.html'), 'utf8');
  assert.match(page, /const PULSE_MS = 30000;/);
  assert.match(page, /fetch\('\.\/data', \{ cache: 'no-store' \}\)/);
  assert.match(page, /if \(text !== last\) \{ last = text; data = JSON\.parse\(text\); changedAt = Date\.now\(\); render\(\); \}/);
  assert.ok(!/https?:\/\//.test(page.replace(/<!--[\s\S]*?-->/g, '')), 'the viewer loads nothing from the network');
});

test('the kit runs from a fresh copy, with no path outside its own folder', () => {
  const base = mkdtempSync(join(tmpdir(), 'kit-copy-'));
  const copy = join(base, 'ledger-kit');
  cpSync(KIT, copy, { recursive: true, filter: (src) => !src.endsWith('node_modules') });
  // The one dependency, from wherever this run found it (npm install, or NODE_PATH), so the copy needs nothing of this folder's.
  const found = createRequire(join(KIT, 'package.json')).resolve('yaml');
  const env = { ...process.env, NODE_PATH: found.slice(0, found.lastIndexOf('/node_modules/') + '/node_modules'.length) };
  const run = (...a) => execFileSync(process.execPath, ['cp.mjs', ...a], { cwd: copy, encoding: 'utf8', env });
  assert.match(run('verify', '--project', 'examples/fixit'), /contract intact: v1\.0/);
  assert.match(run('check', '--project', 'examples/fixit'), /38 lines, 10 tasks/);
  for (const f of ['cp.mjs', 'engine.mjs', 'viewer.html']) assert.ok(!readFileSync(join(copy, f), 'utf8').includes('/home/'), `${f} names no absolute path`);
  rmSync(base, { recursive: true });
});

test('every task reads in plain words, and the viewer gets its whole story to drill into', () => {
  const v = view(join(KIT, 'examples/fixit'));
  for (const t of v.tasks) {
    assert.ok(['Ready', 'In progress', 'Blocked', 'Awaiting review', 'Passed', 'Failed', 'Failed, retrying', 'Waiting', 'Dropped', 'Stalled'].includes(t.label), t.label);
    assert.ok(Array.isArray(t.history) && t.history.length > 0, `${t.id} carries its history`);
  }
  assert.ok(v.northStar.statement, 'the north star');
  assert.ok(v.people.personas.length && v.people.outcomes.length, 'the people it serves');
  assert.ok(v.journey.every((s) => s.domains.every((d) => d.capabilities.every((c) => c.definition !== undefined && Array.isArray(c.goals)))), 'each capability\'s definition and goals');
  assert.equal(v.rules.five.length, 5);
});

test('every section and every detail sheet of the viewer renders the worked example with no missing value', async () => {
  const page = readFileSync(join(KIT, 'viewer.html'), 'utf8');
  const js = page.slice(page.indexOf('<script>') + 8, page.lastIndexOf('</script>'));
  const els = {};
  const el = (id) => (els[id] ??= { innerHTML: '', textContent: '', dataset: {}, classList: { toggle() {} } });
  globalThis.document = { getElementById: el, querySelectorAll: () => [], querySelector: () => null, addEventListener() {}, title: '' };
  globalThis.setInterval = () => 0;
  const v = view(join(KIT, 'examples/fixit'));
  globalThis.fetch = async () => ({ ok: true, text: async () => JSON.stringify(v) });
  const run = new Function(`${js}; return { render, setTab: (t) => { tab = t; }, open: (s) => { sheet = s; }, pulse };`)();
  await run.pulse();
  for (const t of ['Overview', 'Journey', 'Work', 'People', 'Rules']) {
    run.setTab(t); run.render();
    assert.ok(els.body.innerHTML.length > 200 && !/undefined|NaN|\[object/.test(els.body.innerHTML), t);
  }
  for (const s of [{ task: v.tasks[0].id }, { cap: v.journey[0].domains[0].capabilities[0].id }, { star: true }]) {
    run.open(s); run.render();
    assert.ok(els.sheet.innerHTML.length > 100 && !/undefined|NaN|\[object/.test(els.sheet.innerHTML), JSON.stringify(s));
  }
  assert.ok(!/overflow-x/.test(page), 'nothing scrolls sideways');
});

test('the commands in AGENTS.md work as written: a note, a focus with its reason, a verdict', () => {
  const p = mkdtempSync(join(tmpdir(), 'kit-agents-'));
  cpSync(join(KIT, 'examples/fixit'), p, { recursive: true });
  const found = createRequire(join(KIT, 'package.json')).resolve('yaml');
  const env = { ...process.env, NODE_PATH: found.slice(0, found.lastIndexOf('/node_modules/') + '/node_modules'.length) };
  const run = (...a) => execFileSync(process.execPath, [join(KIT, 'cp.mjs'), ...a, '--project', p], { encoding: 'utf8', env });
  assert.match(run('note', 'T2', 'slot list needs a loading state', '--who', 'ben'), /appended/);
  assert.match(run('focus', '--order', 'repair', '--evidence', 'test:repair.test.mjs', 'approvals lose riders', '--who', 'ceremony'), /appended/);
  assert.match(run('verdict', 'T4', '--result', 'pass', '--who', 'reviewer', '--evidence', 'mm3:MM3-1'), /appended/);
  const st = state(p);
  assert.deepEqual(st.focus, ['repair']);
  assert.equal(st.tasks.T4.status, 'passed');
  assert.ok(st.tasks.T2.notes.includes('slot list needs a loading state'));
  rmSync(p, { recursive: true });
});
