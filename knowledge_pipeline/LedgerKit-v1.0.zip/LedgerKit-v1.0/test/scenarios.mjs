// The original ledger guide's scenarios, run with the guide's rules enforced so each refusal it specified is still proven. Each is a list of
// lines; `expect` is "ok" or the rule that must reject a line. The board scenarios retired with the board (the page shows it).
import { apply, brief, empty, Violation, waveStatus, LIMITS } from '../engine.mjs';

const E = (ref = 'abc') => [{ type: 'test', ref }];
const MM3 = (ref) => [{ type: 'mm3', ref, verdict: 'pass' }];
const ACC = ['returns the parsed tree'];
let clock = 0;
const L = (kind, who, extra = {}) => (st) => ({
  kind,
  who,
  ts: `2026-10-23T10:${String(clock++ % 60).padStart(2, '0')}:00.000Z`,
  text: `${kind} by ${who}`,
  ...Object.fromEntries(Object.entries(extra).map(([k, v]) => [k, typeof v === 'function' ? v(st) : v])),
});

// building blocks
const wave = (extra = {}) => L('wave', 'op', { wave: 'W1', title: 'Parser', goal: 'the parser handles real input', ...extra });
const task = (id, extra = {}) => L('task', 'op', { task: id, title: `Do ${id}`, acceptance: ACC, wave: 'W1', ...extra });
const setup = (budget) => [wave(), task('T1', budget ? { budget } : {})];
const work = (who = 'a', cost) => [L('start', who, { task: 'T1' }), L('done', who, { task: 'T1', evidence: E(), ...(cost ? { cost } : {}) })];
const pass = () => L('verdict', 'ev', { task: 'T1', result: 'pass', criteria: [{ criterion: ACC[0], result: 'pass' }], evidence: MM3('MM3-1') });
const fail = (extraCriterion) => L('verdict', 'ev', { task: 'T1', result: 'fail', criteria: [{ criterion: ACC[0], result: extraCriterion ? 'pass' : 'fail' }, ...(extraCriterion ? [{ criterion: extraCriterion, result: 'fail' }] : [])], evidence: MM3('MM3-2') });
const pm = (cause, resolution) => L('postmortem', 'a', { task: 'T1', cause, resolution, evidence: E('why') });
const close = L('ceremony', 'op', { ceremony: 'C1', closes: ['W1'] });
const opp = (extra = {}) => L('opportunity', 'a', { opp: 'I1', cause: 'source', area: 'stack', from: (st) => st.postmortemIds, ...extra });
const BUG = { task: 'B1', title: 'Empty input crashes', severity: 'high', evidence: E('crash') };

const S = [
  ['1 success path: complete, pass, wave completed, ceremony closes', [...setup(), ...work(), pass(), close], 'ok', (st) => waveStatus(st, 'W1') === 'closed'],
  ['2 completed without evidence is rejected', [...setup(), L('start', 'a', { task: 'T1' }), L('done', 'a', { task: 'T1' })], 'no-evidence'],
  ['3 the worker cannot be its own Evaluator', [...setup(), ...work(), L('verdict', 'a', { task: 'T1', result: 'pass', criteria: [{ criterion: ACC[0], result: 'pass' }], evidence: E() })], 'self-verdict'],
  ['4 acceptance criteria missed -> post-mortem -> retry -> pass (no new task)', [...setup(), ...work(), fail(), pm('skill', 'retry'), ...work(), pass(), close], 'ok', (st) => Object.keys(st.tasks).length === 1 && st.tasks.T1.attempts === 2],
  ['5 ceremony cannot close a wave with an unexplained failure', [...setup(), ...work(), fail(), close], 'wave-not-complete'],
  ['6 ceremony cannot close while a retry is pending', [...setup(), ...work(), fail(), pm('skill', 'retry'), close], 'wave-not-complete'],
  ['7 solved in place first, post-mortem written after (fixed)', [...setup(), ...work(), fail(), ...work(), pass(), pm('task-definition', 'fixed'), close], 'ok', (st) => st.tasks.T1.status === 'passed' && st.tasks.T1.fails === 1],
  ['8 solved in place, ceremony before the post-mortem is refused', [...setup(), ...work(), fail(), ...work(), pass(), close], 'wave-not-complete'],
  ['9 MM3 validation failed: a failed criterion with the MM3 run as evidence', [...setup(), ...work(), fail('mm3 validation')], 'ok', (st) => st.tasks.T1.status === 'failed'],
  ['10 verdict that says pass over a failed criterion is refused', [...setup(), ...work(), L('verdict', 'ev', { task: 'T1', result: 'pass', criteria: [{ criterion: ACC[0], result: 'pass' }, { criterion: 'mm3', result: 'fail' }], evidence: E() })], 'verdict-inconsistent'],
  ['11 budget was wrong: overspent work cannot be passed', [...setup(5), ...work('a', 8), pass()], 'over-budget'],
  ['12 budget exhausted: no further start', [...setup(5), ...work('a', 8), fail('budget'), pm('budget', 'retry'), L('start', 'a', { task: 'T1' })], 'budget-exhausted'],
  ['13 budget miss recorded as a failed budget criterion, post-mortem pooled', [...setup(5), ...work('a', 8), fail('budget'), pm('budget', 'pooled'), close], 'ok', (st) => waveStatus(st, 'W1') === 'closed'],
  ['14 post-mortem never creates a task', [...setup(), ...work(), fail(), pm('source', 'pooled')], 'ok', (st) => Object.keys(st.tasks).length === 1],
  ['15 bad cause is refused', [...setup(), ...work(), fail(), pm('vibes', 'pooled')], 'bad-cause'],
  ['16 opportunity with no post-mortem behind it is refused', [...setup(), opp({ from: ['L99'] })], 'no-source'],
  ['17 opportunity from a post-mortem is pooled, not started', [...setup(), ...work(), fail(), pm('source', 'pooled'), opp()], 'ok', (st) => st.opps.I1.status === 'pooled' && st.tasks.T1.status === 'failed'],
  ['18 ceremony pattern count must match its opportunities', [...setup(), ...work(), fail(), pm('source', 'pooled'), opp(), L('ceremony', 'op', { ceremony: 'C1', closes: ['W1'], patterns: [{ cause: 'source', area: 'stack', opportunities: ['I1'], count: 2 }] })], 'pattern-count'],
  ['19 ceremony with a correct pattern over opportunities closes the wave', [...setup(), ...work(), fail(), pm('source', 'pooled'), opp(), L('ceremony', 'op', { ceremony: 'C1', closes: ['W1'], patterns: [{ cause: 'source', area: 'stack', opportunities: ['I1'], count: 1 }] })], 'ok', (st) => waveStatus(st, 'W1') === 'closed'],
  ['20 a pooled opportunity is promoted only when a task cites it', [...setup(), ...work(), fail(), pm('source', 'pooled'), opp(), task('T2', { from: 'I1', wave: undefined })], 'ok', (st) => st.opps.I1.status === 'promoted'],
  ['21 a closed wave refuses new tasks', [...setup(), ...work(), pass(), close, task('T2')], 'wave-closed'],
  ['22 done before start is refused', [...setup(), L('done', 'a', { task: 'T1', evidence: E() })], 'bad-transition'],
  ['23 passed work cannot be restarted', [...setup(), ...work(), pass(), L('start', 'a', { task: 'T1' })], 'bad-transition'],
  ['24 only the owner reports completed', [...setup(), L('start', 'a', { task: 'T1' }), L('done', 'b', { task: 'T1', evidence: E() })], 'not-owner'],
  ['25 a dependency must be passed before start', [...setup(), task('T2', { needs: ['T1'] }), L('start', 'a', { task: 'T2' })], 'needs-unmet'],
  ['26 a need that does not exist is refused (cycles cannot form)', [wave(), task('T2', { needs: ['T3'] })], 'unknown-need'],
  ['27 a dropped member lets the wave complete', [...setup(), L('drop', 'op', { task: 'T1' }), close], 'ok'],
  ['28 settled decision cannot be silently re-decided', [L('decision', 'op', { decision: 'D1', evidence: E('a') }), L('decision', 'op', { decision: 'D1', evidence: E('b') })], 'settled'],
  ['29 reopening a decision with the same evidence is refused', [L('decision', 'op', { decision: 'D1', evidence: E('a') }), L('decision', 'op', { decision: 'D1', for: 'L1', evidence: E('a') })], 'no-new-evidence'],
  ['30 reopening a decision with new evidence is allowed', [L('decision', 'op', { decision: 'D1', evidence: E('a') }), L('decision', 'op', { decision: 'D1', for: 'L1', evidence: E('b') })], 'ok'],
  ['31 a post-mortem without evidence is refused', [...setup(), ...work(), fail(), L('postmortem', 'a', { task: 'T1', cause: 'skill', resolution: 'pooled' })], 'no-evidence'],
  ['32 "fixed" on a task that is still failed is refused', [...setup(), ...work(), fail(), pm('skill', 'fixed')], 'resolution-mismatch'],
  ['33 an agent that died mid-task: another blocks it, then takes over; the old owner can no longer report it', [...setup(), L('start', 'a', { task: 'T1' }), L('block', 'b', { task: 'T1' }), L('start', 'b', { task: 'T1' }), L('done', 'a', { task: 'T1', evidence: E() })], 'not-owner'],
  // naming and short descriptions
  ['34 an id that does not follow the naming standard is refused', [wave(), task('X1')], 'bad-id'],
  ['35 a wave id must be W<number>', [wave({ wave: 'G1' })], 'bad-id'],
  ['36 a title over the limit is refused', [wave(), task('T1', { title: 'x'.repeat(LIMITS.title + 1) })], 'title-too-long'],
  ['37 a wave needs a goal', [wave({ goal: undefined })], 'no-goal'],
  ['38 a wave goal over the limit is refused', [wave({ goal: 'x'.repeat(91) })], 'goal-too-long'],
  ['39 a task needs acceptance criteria', [wave(), task('T1', { acceptance: undefined })], 'no-acceptance'],
  ['39b an acceptance criterion over the limit is refused', [wave(), task('T1', { acceptance: ['x'.repeat(LIMITS.criterion + 1)] })], 'acceptance-too-long'],
  ['40 a verdict must judge every acceptance criterion the task listed', [wave(), task('T1', { acceptance: ['one', 'two'] }), ...work(), L('verdict', 'ev', { task: 'T1', result: 'pass', criteria: [{ criterion: 'one', result: 'pass' }], evidence: E() })], 'verdict-missing-criteria'],
  ['41 a task in a wave that does not exist is refused', [task('T1')], 'unknown-wave'],
  // bugs
  ['42 a bug states its severity first', [wave(), task('B1', { ...BUG, severity: undefined })], 'no-severity'],
  ['43 a bug cites the evidence that it fails', [wave(), task('B1', { ...BUG, evidence: undefined })], 'bug-no-evidence'],
  ['44 a bug with severity and evidence follows the same states and closes its wave', [wave(), task('B1', BUG), L('start', 'a', { task: 'B1' }), L('done', 'a', { task: 'B1', evidence: E() }), L('verdict', 'ev', { task: 'B1', result: 'pass', criteria: [{ criterion: ACC[0], result: 'pass' }], evidence: E() }), close], 'ok', (st) => st.tasks.B1.severity === 'high' && waveStatus(st, 'W1') === 'closed'],
];

/** The guide's own rules: enforced here so each refusal it specified is still proven. Rules added in T913 keep their warn mode. */
export const GUIDE_RULES = ['no-title', 'title-too-long', 'no-goal', 'goal-too-long', 'no-acceptance', 'acceptance-too-long', 'bad-skills', 'needs-unmet',
  'not-owner', 'wave-closed', 'budget-exhausted', 'over-budget', 'verdict-missing-criteria', 'nothing-to-explain', 'bad-cause', 'bad-resolution',
  'resolution-mismatch', 'no-source', 'wave-not-complete', 'pattern-count', 'pattern-mismatch', 'bad-retire', 'bad-source', 'no-severity', 'bug-no-evidence'];

/** Runs every guide scenario with the guide's rules enforced; returns the names that did not behave as specified. */
export function runGuide() {
  const failed = [];
  for (const [name, steps, expect, check] of S) {
    const st = empty({ modes: Object.fromEntries(GUIDE_RULES.map((r) => [r, 'enforce'])) });
    let got = 'ok';
    let at = steps.length - 1;
    try {
      steps.forEach((step, i) => {
        at = i;
        apply(st, step(st));
      });
    } catch (e) {
      if (!(e instanceof Violation)) throw e;
      got = at === steps.length - 1 ? e.rule : `${e.rule} (too early, step ${at + 1} of ${steps.length})`;
    }
    if (!(got === expect && (got !== 'ok' || !check || check(st)))) failed.push(`${name} (expected ${expect}, got ${got})`);
  }
  return { count: S.length, failed };
}

export const parts = { L, wave, task, setup, work, pass, fail, pm, close, opp, E, MM3, ACC, BUG };
