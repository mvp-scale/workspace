// The kit's engine: the original guide's scenarios still hold, and each rule added with the operator behaves as agreed:
// warn first and promote after three runs, day-one rules refused, the hash chain, the shared space, steps, validators, bugs, focus and stale.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { apply, empty, replay, serialise, readyToEnforce, ready, stale, brief, priorityOf, Violation } from '../engine.mjs';
import { runGuide } from './scenarios.mjs';

const SPACE = {
  stages: new Set(['evaluate', 'run']),
  domains: new Map([['D01', 'evaluate'], ['D08', 'run']]),
  capabilities: new Map([['demo', 'D01'], ['running', 'D08'], ['integrations', 'D08']]),
  goals: new Map([['demo.guided-run', 'demo'], ['running.kickoff', 'running']]),
  order: ['demo', 'running', 'integrations'],
};
let clock = 0;
const line = (kind, who, extra = {}) => ({ kind, who, ts: new Date(Date.UTC(2026, 9, 23, 10, 0, clock++)).toISOString(), text: `${kind} by ${who}`, ...extra });
const E = [{ type: 'test', ref: 'x' }];
const task = (id, extra = {}) => line('task', 'op', { task: id, title: `Do ${id}`, acceptance: ['it works'], steps: ['one', 'two'], ...extra });
const refused = (st, l) => { try { apply(st, l); return null; } catch (e) { if (e instanceof Violation) return e.rule; throw e; } };
const rules = (r) => r.warnings.map((w) => w.rule);

test('every guide scenario behaves as specified with the guide rules enforced', () => {
  const r = runGuide();
  assert.deepEqual(r.failed, []);
  assert.ok(r.count >= 45);
});

test('a rule in warn mode lets the line through and returns the warning with its reason and fix', () => {
  const st = empty({ space: SPACE });
  const r = apply(st, task('T1', { title: 'x'.repeat(61) }));
  assert.deepEqual(rules(r), ['title-too-long']);
  assert.ok(r.warnings[0].text && r.warnings[0].fix);
  assert.ok(st.tasks.T1, 'the line was accepted');
});

test('the day-one rules refuse in every mode: done without evidence, self-verdict, an id the contract lacks, unvalidated code', () => {
  const st = empty({ space: SPACE });
  apply(st, task('T1', { validator: 'npm run validate' }));
  apply(st, line('start', 'a', { task: 'T1' }));
  assert.equal(refused(st, line('done', 'a', { task: 'T1' })), 'no-evidence');
  assert.equal(refused(st, line('done', 'a', { task: 'T1', evidence: E })), 'no-validation');
  apply(st, line('done', 'a', { task: 'T1', evidence: [{ type: 'validate', ref: 'green at abc' }] }));
  assert.equal(refused(st, line('verdict', 'a', { task: 'T1', result: 'pass', criteria: [{ criterion: 'it works', result: 'pass' }], evidence: E })), 'self-verdict');
  assert.equal(refused(st, task('T2', { capability: 'nowhere' })), 'unknown-space');
});

test('an exception with a reason lets a done through without its validator, and is counted', () => {
  const st = empty();
  apply(st, task('T1', { validator: 'npm run validate' }));
  apply(st, line('start', 'a', { task: 'T1' }));
  apply(st, line('exception', 'a', { task: 'T1', rule: 'no-validation', text: 'docs only', evidence: E }));
  apply(st, line('done', 'a', { task: 'T1', evidence: E }));
  assert.equal(st.tasks.T1.status, 'completed');
  assert.equal(st.exceptions.length, 1);
});

test('three warnings on separate tasks make a rule ready to enforce; a decision citing them enforces it', () => {
  const st = empty();
  for (const id of ['T1', 'T2', 'T3']) {
    const r = apply(st, task(id, { title: 'x'.repeat(61) }));
    for (const w of r.warnings) apply(st, line('warning', 'engine', { rule: w.rule, task: id, text: w.text }));
  }
  const ready = readyToEnforce(st);
  assert.deepEqual(ready.map((r) => [r.rule, r.runs]), [['title-too-long', 3]]);
  apply(st, line('decision', 'op', { decision: 'D1', rule: 'title-too-long', mode: 'enforce', evidence: ready[0].warnings.map((ref) => ({ type: 'line', ref })) }));
  assert.equal(refused(st, task('T4', { title: 'x'.repeat(61) })), 'title-too-long');
  assert.deepEqual(readyToEnforce(st), [], 'an enforced rule is no longer waiting');
});

test('the chain: a file replays, and an edited or removed line breaks it', () => {
  const st = empty();
  const raws = [task('T1'), line('start', 'a', { task: 'T1' }), line('note', 'a', { task: 'T1', text: 'halfway' })].map((l) => { const raw = serialise(st, l); apply(st, JSON.parse(raw)); return raw; });
  assert.equal(replay(raws.join('\n')).tasks.T1.status, 'in_progress');
  const edited = [raws[0].replace('Do T1', 'Do T9'), raws[1], raws[2]].join('\n');
  assert.throws(() => replay(edited), (e) => e.rule === 'chain-broken' && e.line === 2);
  assert.throws(() => replay([raws[0], raws[2]].join('\n')), (e) => e.rule === 'chain-broken');
});

test('the shared space: a mismatch, a task across capabilities and a wave across domains each warn', () => {
  const st = empty({ space: SPACE });
  assert.deepEqual(rules(apply(st, task('T1', { capability: 'demo', goal: 'running.kickoff' }))), ['space-mismatch']);
  assert.deepEqual(rules(apply(st, task('T2', { capabilities: ['running', 'integrations'] }))), ['spans-capabilities']);
  apply(st, line('wave', 'op', { wave: 'W1', title: 'Run', goal: 'runs finish', domain: 'D08' }));
  assert.deepEqual(rules(apply(st, task('T3', { wave: 'W1', domain: 'D01' }))), ['wave-spans-domains']);
});

test('steps: starting with none, closing one out of order and finishing early each warn', () => {
  const st = empty();
  apply(st, task('T1', { steps: undefined }));
  assert.deepEqual(rules(apply(st, line('start', 'a', { task: 'T1' }))), ['no-steps']);
  apply(st, task('T2'));
  apply(st, line('start', 'a', { task: 'T2' }));
  assert.deepEqual(rules(apply(st, line('step', 'a', { task: 'T2', step: 2 }))), ['step-order']);
  apply(st, task('T3'));
  apply(st, line('start', 'a', { task: 'T3' }));
  apply(st, line('step', 'a', { task: 'T3', step: 1 }));
  assert.deepEqual(rules(apply(st, line('done', 'a', { task: 'T3', evidence: E }))), ['steps-unfinished']);
});

test('a bug\'s priority is computed from severity and blast, and a low or medium bug is pointed to the pool', () => {
  assert.equal(priorityOf('high', 'container'), 'P1');
  assert.equal(priorityOf('high', 'system'), 'P1');
  assert.equal(priorityOf('high', 'code'), 'P2');
  assert.equal(priorityOf('medium', 'system'), 'P2');
  assert.equal(priorityOf('medium', 'code'), 'P3');
  assert.equal(priorityOf('low', 'system'), 'P3');
  const st = empty({ space: SPACE });
  const r = apply(st, task('B1', { severity: 'low', blast: 'code', capability: 'running', evidence: E }));
  assert.deepEqual(rules(r), ['bug-not-pooled']);
  assert.equal(st.tasks.B1.priority, 'P3');
  assert.deepEqual(rules(apply(st, task('B2', { severity: 'high', evidence: E }))).sort(), ['no-area', 'no-blast']);
});

test('focus: work is taken in journey order until a focus line moves a capability first', () => {
  const st = empty({ space: SPACE });
  apply(st, task('T1', { capability: 'integrations' }));
  apply(st, task('T2', { capability: 'demo' }));
  apply(st, task('T3', { capability: 'running' }));
  assert.deepEqual(ready(st).map((t) => t.task), ['T2', 'T3', 'T1']);
  apply(st, line('focus', 'op', { order: ['integrations'], evidence: E }));
  assert.deepEqual(ready(st).map((t) => t.task), ['T1', 'T2', 'T3']);
  assert.equal(refused(st, line('focus', 'op', { order: ['nowhere'], evidence: E })), 'unknown-space');
});

test('stale: work in progress with no new line past the window is flagged, never changed', () => {
  const st = empty();
  apply(st, task('T1'));
  apply(st, { ...line('start', 'a', { task: 'T1' }), ts: '2026-10-20T00:00:00.000Z' });
  assert.deepEqual(stale(st, '2026-10-23T00:00:00.000Z', 48), ['T1']);
  assert.deepEqual(stale(st, '2026-10-21T00:00:00.000Z', 48), []);
  assert.equal(st.tasks.T1.status, 'in_progress');
});

test('an imported line records history without warnings, even a done with no evidence', () => {
  const st = empty();
  apply(st, { ...task('T1', { steps: undefined }), imported: true });
  assert.deepEqual(apply(st, { ...line('start', 'a', { task: 'T1' }), imported: true }).warnings, []);
  apply(st, { ...line('done', 'a', { task: 'T1' }), imported: true });
  assert.equal(st.tasks.T1.status, 'completed');
});

test('the brief carries the shared space, validator, steps and acceptance', () => {
  const st = empty({ space: SPACE });
  apply(st, task('T1', { stage: 'run', domain: 'D08', capability: 'running', goal: 'running.kickoff', validator: 'npm run validate' }));
  const b = brief(st, 'T1');
  assert.match(b, /space {4}run › D08 › running › running\.kickoff/);
  assert.match(b, /validate npm run validate/);
  assert.match(b, /steps {4}1\. one/);
  assert.match(b, /accept {3}1\. it works/);
  for (const l of b.split('\n')) assert.ok(l.length <= 80, l);
});

test('the engine enforces exactly what the kit contract\'s rules/ledger.yaml says', async () => {
  const { contract, KIT } = await import('../cp.mjs');
  const { DAY_ONE, READY_AFTER, SEVERITIES, BLASTS } = await import('../engine.mjs');
  const { readFileSync } = await import('node:fs');
  const { createRequire } = await import('node:module');
  const Y = createRequire(`${KIT}/package.json`)('yaml');
  for (const r of [Y.parse(readFileSync(`${KIT}/contract/v1.0/rules/ledger.yaml`, 'utf8')), contract(`${KIT}/examples/fixit`).rules.ledger]) {
    assert.deepEqual([...DAY_ONE].sort(), [...r.enforcement.day_one.rules].sort());
    assert.equal(READY_AFTER, r.enforcement.ready_after);
    assert.deepEqual(SEVERITIES, r.bugs.severity);
    assert.deepEqual(BLASTS, r.bugs.blast);
  }
});
